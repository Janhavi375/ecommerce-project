// routes/reviews.js
const { readDB, writeDB, nextId } = require('../db');

function reviewsRoutes(req, res, url, method, body, user) {

  // GET /api/reviews?productId=X
  if (method === 'GET' && url.pathname === '/api/reviews') {
    const db = readDB();
    const productId = url.searchParams.get('productId');
    const reviews = productId
      ? db.reviews.filter(r => r.productId === Number(productId))
      : db.reviews;
    return res.json({ reviews, total: reviews.length });
  }

  // POST /api/reviews — add review (must be logged in)
  if (method === 'POST' && url.pathname === '/api/reviews') {
    if (!user) return res.status(401).json({ error: 'Login required to leave a review' });
    const { productId, rating, comment } = body;
    if (!productId || !rating) return res.status(400).json({ error: 'productId and rating are required' });
    if (rating < 1 || rating > 5) return res.status(400).json({ error: 'Rating must be between 1 and 5' });

    const db = readDB();
    const product = db.products.find(p => p.id === Number(productId));
    if (!product) return res.status(404).json({ error: 'Product not found' });

    // Check if user already reviewed
    const existing = db.reviews.find(r => r.productId === Number(productId) && r.userId === user.id);
    if (existing) return res.status(409).json({ error: 'You have already reviewed this product' });

    const review = {
      id: nextId(db.reviews),
      productId: Number(productId),
      userId: user.id,
      userName: user.name,
      rating: Number(rating),
      comment: comment || '',
      createdAt: new Date().toISOString()
    };
    db.reviews.push(review);

    // Update product average rating
    const productReviews = db.reviews.filter(r => r.productId === Number(productId));
    product.rating = Math.round((productReviews.reduce((s, r) => s + r.rating, 0) / productReviews.length) * 10) / 10;
    product.reviews = productReviews.length;

    writeDB(db);
    return res.status(201).json(review);
  }

  // DELETE /api/reviews/:id — delete review (owner or admin)
  const matchDelete = url.pathname.match(/^\/api\/reviews\/(\d+)$/);
  if (method === 'DELETE' && matchDelete) {
    if (!user) return res.status(401).json({ error: 'Login required' });
    const db = readDB();
    const idx = db.reviews.findIndex(r => r.id === Number(matchDelete[1]));
    if (idx === -1) return res.status(404).json({ error: 'Review not found' });
    if (user.role !== 'admin' && db.reviews[idx].userId !== user.id) {
      return res.status(403).json({ error: 'You can only delete your own reviews' });
    }
    db.reviews.splice(idx, 1);
    writeDB(db);
    return res.json({ message: 'Review deleted' });
  }

  return null;
}

module.exports = { reviewsRoutes };
