// routes/admin.js
const { readDB } = require('../db');

function adminRoutes(req, res, url, method, body, user) {
  if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });

  // GET /api/admin/stats — dashboard stats
  if (method === 'GET' && url.pathname === '/api/admin/stats') {
    const db = readDB();
    const totalRevenue = db.orders
      .filter(o => o.status !== 'cancelled')
      .reduce((s, o) => s + o.total, 0);
    const statusCounts = {};
    db.orders.forEach(o => {
      statusCounts[o.status] = (statusCounts[o.status] || 0) + 1;
    });
    const topProducts = [...db.products]
      .sort((a, b) => b.reviews - a.reviews)
      .slice(0, 5)
      .map(p => ({ id: p.id, name: p.name, brand: p.brand, price: p.price, reviews: p.reviews, stock: p.stock }));
    const lowStock = db.products.filter(p => p.stock < 10).map(p => ({ id: p.id, name: p.name, stock: p.stock }));

    return res.json({
      stats: {
        totalProducts: db.products.length,
        totalUsers: db.users.length,
        totalOrders: db.orders.length,
        totalRevenue,
        ordersByStatus: statusCounts,
        averageOrderValue: db.orders.length ? Math.round(totalRevenue / db.orders.length) : 0
      },
      topProducts,
      lowStockAlerts: lowStock
    });
  }

  // GET /api/admin/users — list all users
  if (method === 'GET' && url.pathname === '/api/admin/users') {
    const db = readDB();
    const users = db.users.map(({ password, ...u }) => u); // exclude passwords
    return res.json({ users, total: users.length });
  }

  return null;
}

module.exports = { adminRoutes };
