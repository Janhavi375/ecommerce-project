// routes/cart.js
const { readDB, writeDB } = require('../db');

function cartRoutes(req, res, url, method, body, user) {
  // Cart is per user (userId). Guest cart uses sessionId from header.
  const userId = user ? `user_${user.id}` : (req.headers['x-session-id'] || 'guest');

  // GET /api/cart
  if (method === 'GET' && url.pathname === '/api/cart') {
    const db = readDB();
    const session = db.cart_sessions.find(s => s.userId === userId);
    if (!session) return res.json({ items: [], total: 0, count: 0 });

    const enriched = session.items.map(item => {
      const product = db.products.find(p => p.id === item.productId);
      return product
        ? { ...item, name: product.name, brand: product.brand, icon: product.icon, price: product.price, maxStock: product.stock }
        : item;
    });
    const total = enriched.reduce((s, i) => s + i.price * i.qty, 0);
    const count = enriched.reduce((s, i) => s + i.qty, 0);
    return res.json({ items: enriched, total, count });
  }

  // POST /api/cart — add item
  if (method === 'POST' && url.pathname === '/api/cart') {
    const { productId, qty = 1 } = body;
    if (!productId) return res.status(400).json({ error: 'productId is required' });

    const db = readDB();
    const product = db.products.find(p => p.id === Number(productId));
    if (!product) return res.status(404).json({ error: 'Product not found' });
    if (product.stock < 1) return res.status(400).json({ error: 'Product out of stock' });

    let session = db.cart_sessions.find(s => s.userId === userId);
    if (!session) {
      session = { userId, items: [] };
      db.cart_sessions.push(session);
    }
    const existing = session.items.find(i => i.productId === Number(productId));
    if (existing) {
      existing.qty = Math.min(existing.qty + Number(qty), product.stock);
    } else {
      session.items.push({ productId: Number(productId), qty: Math.min(Number(qty), product.stock) });
    }
    writeDB(db);
    return res.json({ message: 'Added to cart', productName: product.name });
  }

  // PUT /api/cart/:productId — update quantity
  const matchUpdate = url.pathname.match(/^\/api\/cart\/(\d+)$/);
  if (method === 'PUT' && matchUpdate) {
    const { qty } = body;
    if (qty === undefined) return res.status(400).json({ error: 'qty is required' });

    const db = readDB();
    const session = db.cart_sessions.find(s => s.userId === userId);
    if (!session) return res.status(404).json({ error: 'Cart not found' });

    const item = session.items.find(i => i.productId === Number(matchUpdate[1]));
    if (!item) return res.status(404).json({ error: 'Item not in cart' });

    if (Number(qty) <= 0) {
      session.items = session.items.filter(i => i.productId !== Number(matchUpdate[1]));
    } else {
      item.qty = Number(qty);
    }
    writeDB(db);
    return res.json({ message: 'Cart updated' });
  }

  // DELETE /api/cart/:productId — remove item
  const matchDelete = url.pathname.match(/^\/api\/cart\/(\d+)$/);
  if (method === 'DELETE' && matchDelete) {
    const db = readDB();
    const session = db.cart_sessions.find(s => s.userId === userId);
    if (session) {
      session.items = session.items.filter(i => i.productId !== Number(matchDelete[1]));
      writeDB(db);
    }
    return res.json({ message: 'Item removed' });
  }

  // DELETE /api/cart — clear cart
  if (method === 'DELETE' && url.pathname === '/api/cart') {
    const db = readDB();
    const idx = db.cart_sessions.findIndex(s => s.userId === userId);
    if (idx !== -1) db.cart_sessions.splice(idx, 1);
    writeDB(db);
    return res.json({ message: 'Cart cleared' });
  }

  return null;
}

module.exports = { cartRoutes };
