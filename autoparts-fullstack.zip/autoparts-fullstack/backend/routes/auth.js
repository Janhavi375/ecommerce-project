// routes/auth.js
const { readDB, writeDB, nextId } = require('../db');
const { signToken, hashPassword } = require('../middleware/auth');

function authRoutes(req, res, url, method, body) {

  // POST /api/auth/register
  if (method === 'POST' && url.pathname === '/api/auth/register') {
    const { name, email, password } = body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'name, email, and password are required' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }
    const db = readDB();
    if (db.users.find(u => u.email === email)) {
      return res.status(409).json({ error: 'Email already registered' });
    }
    const user = {
      id: nextId(db.users),
      name, email,
      password: hashPassword(password),
      role: 'customer',
      createdAt: new Date().toISOString()
    };
    db.users.push(user);
    writeDB(db);
    const token = signToken({ id: user.id, email: user.email, name: user.name, role: user.role });
    return res.status(201).json({
      message: 'Registration successful',
      token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role }
    });
  }

  // POST /api/auth/login
  if (method === 'POST' && url.pathname === '/api/auth/login') {
    const { email, password } = body;
    if (!email || !password) {
      return res.status(400).json({ error: 'email and password are required' });
    }
    const db = readDB();
    const user = db.users.find(u => u.email === email);
    if (!user || user.password !== hashPassword(password)) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    const token = signToken({ id: user.id, email: user.email, name: user.name, role: user.role });
    return res.json({
      message: 'Login successful',
      token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role }
    });
  }

  // GET /api/auth/me — get current user profile
  if (method === 'GET' && url.pathname === '/api/auth/me') {
    return null; // handled in server.js after auth middleware
  }

  return null;
}

module.exports = { authRoutes };
