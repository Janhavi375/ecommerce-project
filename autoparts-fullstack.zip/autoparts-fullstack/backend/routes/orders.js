// routes/orders.js
const { readDB, writeDB, nextId } = require('../db');

const ORDER_STATUSES = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'];

function ordersRoutes(req, res, url, method, body, user) {
  if (!user) return res.status(401).json({ error: 'Login required' });

  // GET /api/orders — list user's orders (admin sees all)
  if (method === 'GET' && url.pathname === '/api/orders') {
    const db = readDB();
    const orders = user.role === 'admin'
      ? db.orders
      : db.orders.filter(o => o.userId === user.id);
    return res.json({ orders, total: orders.length });
  }

  // GET /api/orders/:id
  const matchSingle = url.pathname.match(/^\/api\/orders\/(\d+)$/);
  if (method === 'GET' && matchSingle) {
    const db = readDB();
    const order = db.orders.find(o => o.id === Number(matchSingle[1]));
    if (!order) return res.status(404).json({ error: 'Order not found' });
    if (user.role !== 'admin' && order.userId !== user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }
    return res.json(order);
  }

  // POST /api/orders — place order from cart
  if (method === 'POST' && url.pathname === '/api/orders') {
    const { shippingAddress, paymentMethod } = body;
    if (!shippingAddress || !paymentMethod) {
      return res.status(400).json({ error: 'shippingAddress and paymentMethod are required' });
    }

    const db = readDB();

    // Get cart
    const session = db.cart_sessions.find(s => s.userId === `user_${user.id}`);
    if (!session || session.items.length === 0) {
      return res.status(400).json({ error: 'Cart is empty' });
    }

    // Build order items & check stock
    const orderItems = [];
    for (const cartItem of session.items) {
      const product = db.products.find(p => p.id === cartItem.productId);
      if (!product) return res.status(400).json({ error: `Product ${cartItem.productId} not found` });
      if (product.stock < cartItem.qty) {
        return res.status(400).json({ error: `Insufficient stock for ${product.name}` });
      }
      orderItems.push({
        productId: product.id,
        name: product.name,
        brand: product.brand,
        icon: product.icon,
        price: product.price,
        qty: cartItem.qty,
        subtotal: product.price * cartItem.qty
      });
    }

    const subtotal = orderItems.reduce((s, i) => s + i.subtotal, 0);
    const shipping = subtotal >= 999 ? 0 : 99;
    const tax = Math.round(subtotal * 0.18);
    const total = subtotal + shipping + tax;

    // Deduct stock
    orderItems.forEach(item => {
      const product = db.products.find(p => p.id === item.productId);
      product.stock -= item.qty;
    });

    // Create order
    const order = {
      id: nextId(db.orders),
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      items: orderItems,
      shippingAddress,
      paymentMethod,
      paymentStatus: paymentMethod === 'cod' ? 'pending' : 'paid',
      status: 'confirmed',
      subtotal, shipping, tax, total,
      trackingNumber: `AP${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    db.orders.push(order);

    // Clear cart
    const cartIdx = db.cart_sessions.findIndex(s => s.userId === `user_${user.id}`);
    if (cartIdx !== -1) db.cart_sessions.splice(cartIdx, 1);

    writeDB(db);
    return res.status(201).json({ message: 'Order placed successfully', order });
  }

  // PATCH /api/orders/:id/status — update status (admin only)
  const matchStatus = url.pathname.match(/^\/api\/orders\/(\d+)\/status$/);
  if (method === 'PATCH' && matchStatus) {
    if (user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
    const { status } = body;
    if (!ORDER_STATUSES.includes(status)) {
      return res.status(400).json({ error: `Invalid status. Must be one of: ${ORDER_STATUSES.join(', ')}` });
    }
    const db = readDB();
    const order = db.orders.find(o => o.id === Number(matchStatus[1]));
    if (!order) return res.status(404).json({ error: 'Order not found' });
    order.status = status;
    order.updatedAt = new Date().toISOString();
    writeDB(db);
    return res.json({ message: 'Status updated', order });
  }

  return null;
}

module.exports = { ordersRoutes };
