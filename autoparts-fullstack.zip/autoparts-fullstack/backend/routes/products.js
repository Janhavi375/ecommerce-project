// routes/products.js
const { readDB, writeDB, nextId } = require('../db');

function productsRoutes(req, res, url, method, body, user) {
  const db = readDB();

  // GET /api/products — list with optional filters
  if (method === 'GET' && url.pathname === '/api/products') {
    let products = db.products;
    const p = url.searchParams;

    if (p.get('category')) {
      products = products.filter(x => x.category.toLowerCase() === p.get('category').toLowerCase());
    }
    if (p.get('brand')) {
      products = products.filter(x => x.brand.toLowerCase() === p.get('brand').toLowerCase());
    }
    if (p.get('q')) {
      const q = p.get('q').toLowerCase();
      products = products.filter(x =>
        x.name.toLowerCase().includes(q) || x.brand.toLowerCase().includes(q) || x.category.toLowerCase().includes(q)
      );
    }
    if (p.get('badge')) {
      products = products.filter(x => x.badge === p.get('badge'));
    }
    if (p.get('minPrice')) products = products.filter(x => x.price >= Number(p.get('minPrice')));
    if (p.get('maxPrice')) products = products.filter(x => x.price <= Number(p.get('maxPrice')));

    // Sorting
    const sort = p.get('sort') || 'id';
    if (sort === 'price_asc') products.sort((a, b) => a.price - b.price);
    else if (sort === 'price_desc') products.sort((a, b) => b.price - a.price);
    else if (sort === 'rating') products.sort((a, b) => b.rating - a.rating);
    else if (sort === 'popular') products.sort((a, b) => b.reviews - a.reviews);

    // Pagination
    const page = Math.max(1, Number(p.get('page')) || 1);
    const limit = Math.min(50, Number(p.get('limit')) || 12);
    const total = products.length;
    const data = products.slice((page - 1) * limit, page * limit);

    return res.json({ data, total, page, limit, pages: Math.ceil(total / limit) });
  }

  // GET /api/products/categories — list all categories with counts
  if (method === 'GET' && url.pathname === '/api/products/categories') {
    const counts = {};
    db.products.forEach(p => {
      counts[p.category] = (counts[p.category] || 0) + 1;
    });
    const categories = Object.entries(counts).map(([name, count]) => ({ name, count }));
    return res.json({ categories });
  }

  // GET /api/products/:id — single product
  const matchSingle = url.pathname.match(/^\/api\/products\/(\d+)$/);
  if (method === 'GET' && matchSingle) {
    const product = db.products.find(p => p.id === Number(matchSingle[1]));
    if (!product) return res.status(404).json({ error: 'Product not found' });
    const productReviews = db.reviews.filter(r => r.productId === product.id);
    return res.json({ ...product, reviewList: productReviews });
  }

  // POST /api/products — create (admin only)
  if (method === 'POST' && url.pathname === '/api/products') {
    if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
    const { name, brand, category, price, stock, description } = body;
    if (!name || !brand || !category || !price) {
      return res.status(400).json({ error: 'name, brand, category, price are required' });
    }
    const product = {
      id: nextId(db.products), name, brand, category,
      price: Number(price), oldPrice: body.oldPrice ? Number(body.oldPrice) : null,
      stock: Number(stock) || 0, icon: body.icon || '📦',
      badge: body.badge || null, rating: 0, reviews: 0,
      description: description || '', createdAt: new Date().toISOString()
    };
    db.products.push(product);
    writeDB(db);
    return res.status(201).json(product);
  }

  // PUT /api/products/:id — update (admin only)
  const matchUpdate = url.pathname.match(/^\/api\/products\/(\d+)$/);
  if (method === 'PUT' && matchUpdate) {
    if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
    const idx = db.products.findIndex(p => p.id === Number(matchUpdate[1]));
    if (idx === -1) return res.status(404).json({ error: 'Product not found' });
    db.products[idx] = { ...db.products[idx], ...body, id: db.products[idx].id };
    writeDB(db);
    return res.json(db.products[idx]);
  }

  // DELETE /api/products/:id — delete (admin only)
  const matchDelete = url.pathname.match(/^\/api\/products\/(\d+)$/);
  if (method === 'DELETE' && matchDelete) {
    if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
    const idx = db.products.findIndex(p => p.id === Number(matchDelete[1]));
    if (idx === -1) return res.status(404).json({ error: 'Product not found' });
    db.products.splice(idx, 1);
    writeDB(db);
    return res.json({ message: 'Product deleted' });
  }

  return null; // route not matched
}

module.exports = { productsRoutes };
